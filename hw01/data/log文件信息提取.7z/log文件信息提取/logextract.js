if(WScript.Arguments.Length < 1 ){
	WScript.Echo("�����벹��log�ļ�����Ϊ����");
	WScript.Quit(1);
}
var fso = new ActiveXObject("Scripting.FileSystemObject");
if(!fso.FileExists(WScript.Arguments(0))){
	WScript.Echo("�����Ҳ���ָ����log�ļ�");
	WScript.Quit(1);
}

var logFile = WScript.Arguments(0);
var data = extractInfo(logFile);
var xlsFile = saveToExcel(logFile, data);
WScript.Echo("�����õ�Excel�ļ���" + xlsFile);
//openXLS(xlsFile);

function extractInfo(logFile){
	var ForReading = 1, ForWriting = 2, ForAppending = 8;
	var f = fso.OpenTextFile(logFile, ForReading);
	var re_iso = /Isotropic =/;
	var re_ani = /Anisotropy =/;
	var re_space = /\s+/;
	var arrElement = new Array();
	while (!f.AtEndOfStream){
	    var line = f.ReadLine();
	    if(line.indexOf("Isotropic =")>0){
		    line =  line.replace(re_iso,"");
		    line =  line.replace(re_ani,"");
		    var fields =  line.split(re_space);
		    if(!arrElement[fields[1]]){
			    arrElement[fields[1]] = new Array();
		    }
		    arrElement[fields[1]].push(fields.join("\t"));
	    }
	}
	f.Close();
	return arrElement;
}

function saveToExcel(logFile, data){
	var colName = ["No.", "Atom", "Isotropic", "Anisotropy"];
	var excelApp = new ActiveXObject("Excel.Application");
	var excelWorkBook = excelApp.Workbooks.Add;
	for(var atom in data){
		var excelSheet = excelWorkBook.Worksheets.Add();
		excelSheet.Name = atom;
		for(var i = 0; i < colName.length; i++){
			excelSheet.Cells(1, i + 1) = colName[i];
		}
		var rowStart = 2;
		var colStart = 1;
		for(var i=0; i<data[atom].length; i++){
			var line = data[atom][i];
			var cols = line.split("\t");
			for(var j=0; j<cols.length; j++){
				excelSheet.Cells(i + rowStart, j + colStart).value = cols[j];
			}
		}
	}
	var xlsFileName = fso.GetAbsolutePathName(logFile).replace(/\.log/gi, ".xls");
	excelWorkBook.SaveAs(xlsFileName);
	excelSheet=null;
	excelWorkBook.close();
	excelApp.Application.Quit();
	excelApp=null;
	return xlsFileName;
}

function openXLS(file){
	var shell = WScript.CreateObject("WScript.Shell");
	var cmd = "start \"\" /max " + "\"" + file +"\"";
	WScript.Echo(cmd);
	shell.Run(cmd);
}
function parseFile(filename)
    fp = fopen(filename, 'rt');
    i=1;
    result={'','','',''}; %['No.','Atom','Isotropic','Anisotropy'];
    result=repmat(result,1000000000,1);
    while(feof(fp)==0)
        line = fgetl(fp); 
        if (isempty(strfind(line, 'Isotropic = '))~=1) && (isempty(strfind(line, 'Anisotropy = '))~=1)
            result=[result;strsplit(strtrim(line),{'Isotropic =','Anisotropy =',' '},'CollapseDelimiters',true)];
        end
    end
    fclose(fp);
    result
end